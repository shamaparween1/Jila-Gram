# Jila Social Reels — APK build code

यह पैकेज Flutter source code और GitHub Actions workflow देता है, जो GitHub पर डालने के बाद APK build करने में मदद करेगा। यह APK फ़ाइल स्वयं नहीं है।

## Android टैबलेट से उपयोग

1. ZIP extract करें।
2. GitHub पर नया **public repository** बनाएँ, उदाहरण: `jila-social`.
3. इस ZIP के अंदर की सभी फ़ाइलें और `.github` फ़ोल्डर भी repository में upload करें। GitHub web interface में hidden `.github` फ़ोल्डर दिखाने/अपलोड करने में दिक्कत हो तो repository में `Add file > Create new file` चुनें और path के रूप में `.github/workflows/build-apk.yml` डालकर workflow content paste करें।
4. `Actions` टैब खोलें। पहली बार workflow enable करने का संकेत आए तो enable करें।
5. `Build Jila Social APK` workflow चुनें और `Run workflow` दबाएँ; या `main` branch में फ़ाइलें push करने पर build शुरू होगा।
6. सफल build के बाद workflow run खोलें, नीचे `Artifacts` में `jila-social-apk` डाउनलोड करें।
7. ZIP artifact को टैबलेट पर extract करें। `app-release.apk` इंस्टॉल करें। Android अगर अनुमति माँगे तो केवल इस डाउनलोड के लिए install unknown apps की अनुमति दें और काम के बाद बंद कर दें।

## ध्यान दें
- Build workflow GitHub-hosted runner पर चलता है; free quota/limits लागू हो सकते हैं।
- यदि `flutter create` मौजूदा फाइलों के कारण fail करे, तो workflow log पढ़ें। तब एक पूरा Flutter scaffold बनाकर `lib/main.dart` और `pubspec.yaml` उसमें कॉपी करना पड़ सकता है।
- यह अभी demo app है: रील स्क्रीन, vertical swipe, like/follow state, comment dialog और caption-only upload demo।
- वास्तविक वीडियो फ़ाइल चयन/प्ले, सर्वर पर अपलोड, यूज़र अकाउंट, persistent likes/comments/follows, chat, moderation dashboard और monetization अभी लागू नहीं हैं।
- किसी भी production release से पहले security rules, privacy policy, reporting/blocking, moderation और data deletion जोड़ें।
