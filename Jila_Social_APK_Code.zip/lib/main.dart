import 'package:flutter/material.dart';

void main() => runApp(const JilaSocialReelsApp());

class JilaSocialReelsApp extends StatelessWidget {
  const JilaSocialReelsApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Jila Social',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0866D9))),
    home: const ReelsHome(),
  );
}

class Reel {
  final String creator, location, caption, colorTag;
  int likes;
  bool liked, following;
  Reel({required this.creator, required this.location, required this.caption, required this.colorTag, this.likes = 0, this.liked = false, this.following = false});
}

class ReelsHome extends StatefulWidget {
  const ReelsHome({super.key});
  @override
  State<ReelsHome> createState() => _ReelsHomeState();
}

class _ReelsHomeState extends State<ReelsHome> {
  int tab = 0;
  final List<Reel> reels = [
    Reel(creator: 'Jila Media News', location: 'पूर्णिया, बिहार', caption: 'अपने जिले की खबरें और खास पल — Jila Social पर। #Purnia #Bihar', colorTag: 'news', likes: 128),
    Reel(creator: 'Bihar Creator', location: 'डगरूआ', caption: 'बिहार की खूबसूरती और लोकल टैलेंट को दुनिया तक पहुँचाएँ।', colorTag: 'travel', likes: 86),
    Reel(creator: 'Apna Purnia', location: 'बायसी', caption: 'आपकी अपनी आवाज़, आपकी अपनी कम्युनिटी।', colorTag: 'community', likes: 43),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    body: tab == 0 ? PageView.builder(
      scrollDirection: Axis.vertical,
      itemCount: reels.length,
      itemBuilder: (context, i) => ReelView(
        reel: reels[i],
        onLike: () => setState(() { reels[i].liked = !reels[i].liked; reels[i].likes += reels[i].liked ? 1 : -1; }),
        onFollow: () => setState(() => reels[i].following = !reels[i].following),
        onComment: () => _comments(reels[i]),
        onUpload: _upload,
      ),
    ) : _otherPage(),
    bottomNavigationBar: NavigationBar(
      backgroundColor: const Color(0xFF101010),
      indicatorColor: const Color(0xFF234D85),
      selectedIndex: tab,
      onDestinationSelected: (v) => setState(() => tab = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.play_circle_outline, color: Colors.white), selectedIcon: Icon(Icons.play_circle, color: Colors.white), label: 'रील्स'),
        NavigationDestination(icon: Icon(Icons.search, color: Colors.white), label: 'खोजें'),
        NavigationDestination(icon: Icon(Icons.add_box_outlined, color: Colors.white), label: 'अपलोड'),
        NavigationDestination(icon: Icon(Icons.chat_bubble_outline, color: Colors.white), label: 'इनबॉक्स'),
        NavigationDestination(icon: Icon(Icons.person_outline, color: Colors.white), label: 'प्रोफाइल'),
      ],
    ),
  );

  Widget _otherPage() => Container(
    color: const Color(0xFF101010),
    child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.video_collection_outlined, color: Colors.white, size: 54),
      const SizedBox(height: 14),
      Text(['', 'वीडियो खोजें', '', 'इनबॉक्स', 'आपकी प्रोफाइल'][tab], style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Padding(padding: EdgeInsets.all(24), child: Text('यह शुरुआती डेमो स्क्रीन है। वास्तविक खोज, चैट और प्रोफाइल के लिए बैकएंड जोड़ना होगा।', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70))),
      if (tab == 2) FilledButton.icon(onPressed: _upload, icon: const Icon(Icons.upload), label: const Text('वीडियो अपलोड करें')),
    ])),
  );

  Future<void> _upload() async {
    final controller = TextEditingController();
    final caption = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('रील अपलोड (डेमो)'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('यह प्रोटोटाइप अभी असली वीडियो फ़ाइल नहीं चुनता। अगले चरण में वीडियो पिकर और क्लाउड अपलोड जोड़ा जाएगा।'),
        const SizedBox(height: 12),
        TextField(controller: controller, maxLines: 2, decoration: const InputDecoration(labelText: 'कैप्शन', border: OutlineInputBorder())),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('रद्द करें')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('डेमो पोस्ट')),
      ],
    ));
    if (caption != null && caption.isNotEmpty && mounted) {
      setState(() => reels.insert(0, Reel(creator: 'आप', location: 'आपकी लोकेशन', caption: caption, colorTag: 'new')));
      setState(() => tab = 0);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('डेमो रील जोड़ी गई। अभी यह वीडियो नहीं, केवल कैप्शन है।')));
    }
  }

  Future<void> _comments(Reel reel) async {
    final controller = TextEditingController();
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('कमेंट्स (डेमो)'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('असली कमेंट्स सर्वर से जुड़ने के बाद सेव होंगे।'),
        const SizedBox(height: 10),
        TextField(controller: controller, decoration: const InputDecoration(hintText: 'कमेंट लिखें…', border: OutlineInputBorder())),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('बंद करें')),
        FilledButton(onPressed: () { Navigator.pop(ctx); if (controller.text.trim().isNotEmpty) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('डेमो कमेंट दर्ज हुआ; अभी सेव नहीं होता।'))); }, child: const Text('भेजें')),
      ],
    ));
  }
}

class ReelView extends StatelessWidget {
  final Reel reel;
  final VoidCallback onLike, onFollow, onComment, onUpload;
  const ReelView({super.key, required this.reel, required this.onLike, required this.onFollow, required this.onComment, required this.onUpload});

  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
    Container(
      decoration: BoxDecoration(gradient: LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: reel.colorTag == 'news'
          ? const [Color(0xFF183B69), Color(0xFF101010), Color(0xFF020202)]
          : reel.colorTag == 'travel'
            ? const [Color(0xFF167A88), Color(0xFF12323D), Color(0xFF020202)]
            : const [Color(0xFF633A83), Color(0xFF24172F), Color(0xFF020202)],
      )),
      child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.play_circle_fill, size: 76, color: Colors.white70),
        const SizedBox(height: 12),
        const Text('JILA SOCIAL', style: TextStyle(color: Colors.white, fontSize: 27, letterSpacing: 3, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('रील वीडियो प्रोटोटाइप', style: TextStyle(color: Colors.white70, fontSize: 15)),
        const SizedBox(height: 18),
        const Icon(Icons.swipe_up_alt, color: Colors.white70, size: 30),
        const Text('अगली रील के लिए ऊपर स्वाइप करें', style: TextStyle(color: Colors.white70)),
      ])),
    ),
    Positioned(left: 16, top: 48, child: Row(children: const [
      CircleAvatar(backgroundColor: Color(0xFF0866D9), child: Text('JS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
      SizedBox(width: 8),
      Text('Jila Social', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
    ])),
    Positioned(right: 12, bottom: 100, child: Column(children: [
      const CircleAvatar(radius: 24, backgroundColor: Colors.white24, child: Icon(Icons.person, color: Colors.white, size: 30)),
      const SizedBox(height: 18),
      IconButton(onPressed: onLike, iconSize: 34, color: reel.liked ? Colors.pinkAccent : Colors.white, icon: Icon(reel.liked ? Icons.favorite : Icons.favorite_border)),
      Text('${reel.likes}', style: const TextStyle(color: Colors.white)),
      const SizedBox(height: 16),
      IconButton(onPressed: onComment, iconSize: 32, color: Colors.white, icon: const Icon(Icons.mode_comment_outlined)),
      const Text('कमेंट', style: TextStyle(color: Colors.white, fontSize: 12)),
      const SizedBox(height: 16),
      IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('शेयर सुविधा बाद में जुड़ेगी।'))), iconSize: 32, color: Colors.white, icon: const Icon(Icons.share_outlined)),
      const Text('शेयर', style: TextStyle(color: Colors.white, fontSize: 12)),
    ])),
    Positioned(left: 16, right: 90, bottom: 112, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Flexible(child: Text('@${reel.creator}', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold))),
        const SizedBox(width: 8),
        OutlinedButton(
          onPressed: onFollow,
          style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70), padding: const EdgeInsets.symmetric(horizontal: 10), minimumSize: const Size(0, 32)),
          child: Text(reel.following ? 'फॉलो किया' : 'फॉलो करें'),
        ),
      ]),
      const SizedBox(height: 4),
      Text(reel.caption, style: const TextStyle(color: Colors.white, fontSize: 14)),
      const SizedBox(height: 8),
      Row(children: [const Icon(Icons.location_on_outlined, color: Colors.white70, size: 16), const SizedBox(width: 3), Text(reel.location, style: const TextStyle(color: Colors.white70, fontSize: 12))]),
    ])),
  ]);
}
